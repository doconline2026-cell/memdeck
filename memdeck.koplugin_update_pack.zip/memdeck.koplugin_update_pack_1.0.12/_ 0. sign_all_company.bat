
@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

echo ============================
echo   DANG KY TAT CA FILE .LUA / .LUAC
echo   (GOC + THU MUC CON ^> Sig\)
echo ============================
echo.

REM ============================================================
REM THU MUC GOC = THU MUC CHUA FILE BAT
REM ============================================================
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"

echo Thu muc goc:
echo    %ROOT%
echo.

REM ============================================================
REM TU DONG TIM OPENSSL
REM ============================================================
set "OPENSSL="

REM 1. Tim trong thu muc BAT
if exist "%ROOT%\openssl.exe" (
    set "OPENSSL=%ROOT%\openssl.exe"
)

REM 2. Tim trong PATH
if not defined OPENSSL (
    where openssl >nul 2>nul
    if not errorlevel 1 (
        set "OPENSSL=openssl"
    )
)

REM 3. Tim cac vi tri pho bien
if not defined OPENSSL (
    for %%P in (
        "%ProgramFiles%\Git\usr\bin\openssl.exe"
        "%ProgramFiles(x86)%\Git\usr\bin\openssl.exe"
        "%LocalAppData%\Programs\Git\mingw64\bin\openssl.exe"
        "%UserProfile%\AppData\Local\Programs\Git\mingw64\bin\openssl.exe"
        "C:\Git\usr\bin\openssl.exe"
        "C:\Program Files\OpenSSL\bin\openssl.exe"
        "C:\Program Files\OpenSSL-Win64\bin\openssl.exe"
    ) do (
        if exist "%%~P" (
            set "OPENSSL=%%~P"
            goto :found_openssl
        )
    )
)

REM 4. Tim tren o C
if not defined OPENSSL (
    echo Dang tim openssl tren o C...
    
    for /f "delims=" %%i in ('where /r C:\ openssl.exe 2^>nul') do (
        set "OPENSSL=%%i"
        goto :found_openssl
    )
)

:found_openssl

if not defined OPENSSL (
    echo.
    echo KHONG TIM THAY OPENSSL
    echo.
    echo Hay cai Git for Windows hoac OpenSSL.
    echo.
    pause
    exit /b 1
)

echo OpenSSL:
echo    %OPENSSL%
echo.

REM ============================================================
REM KIEM TRA PRIVATE KEY
REM ============================================================
set "PRIVATE_KEY=D:\Deverlop\Plugin OK\0. Key sig\keys-moi\sign_private.pem"

if not exist "%PRIVATE_KEY%" (
    echo.
    echo KHONG TIM THAY PRIVATE KEY
    echo.
    echo    %PRIVATE_KEY%
    echo.
    echo Hay sua bien PRIVATE_KEY trong file BAT.
    echo.
    pause
    exit /b 1
)

echo Private key:
echo    %PRIVATE_KEY%
echo.

REM ============================================================
REM KIEM TRA PLUGIN
REM ============================================================
set "PLUGIN=%ROOT%"

if not exist "%PLUGIN%\main.lua" (
    echo.
    echo KHONG TIM THAY main.lua
    echo.
    echo    %PLUGIN%\main.lua
    echo.
    echo File BAT phai nam truc tiep trong thu muc plugin.
    echo.
    pause
    exit /b 1
)

echo Plugin:
echo    %PLUGIN%
echo.

REM ============================================================
REM THU MUC SIG
REM ============================================================
set "SIGROOT=%PLUGIN%\Sig"

if not exist "%SIGROOT%" (
    mkdir "%SIGROOT%"
)

echo Thu muc Sig:
echo    %SIGROOT%
echo.

REM ============================================================
REM DEM FILE
REM ============================================================
set /a COUNT=0

echo ============================================================
echo BAT DAU KY FILE .LUA
echo ============================================================
echo.

REM ============================================================
REM KY TAT CA FILE LUA
REM ============================================================
for /r "%PLUGIN%" %%F in (*.lua) do (

    set "SRC=%%~fF"

    REM Bo qua Sig
    echo(!SRC!| findstr /i /b /c:"%SIGROOT%\" >nul

    if errorlevel 1 (

        REM Lay duong dan tuong doi
        set "REL=%%~fF"
        set "REL=!REL:%PLUGIN%\=!"

        REM Tao duong dan SIG
        set "SIG=%SIGROOT%\!REL!.sig"

        REM Tao thu muc cha cua SIG
        for %%D in ("!SIG!") do (
            if not exist "%%~dpD" mkdir "%%~dpD"
        )

        REM Chuyen ca SRC va SIG sang duong dan 8.3
        set "SRC_S=%%~sF"

        for %%S in ("!SIG!") do (
            set "SIG_S=%%~sS"
        )

        echo ------------------------------------------------------------
        echo KY:
        echo    !SRC!
        echo.
        echo    ^> !SIG!
        echo.

        "%OPENSSL%" dgst -sha256 -sign "%PRIVATE_KEY%" -out "!SIG_S!" "!SRC_S!"

        if errorlevel 1 (
            echo.
            echo LOI KHI KY FILE LUA:
            echo    !SRC!
            echo.
            echo Duong dan nguon:
            echo    !SRC_S!
            echo.
            echo Duong dan chu ky:
            echo    !SIG_S!
            echo.
            pause
            exit /b 1
        )

        echo OK
        echo.

        set /a COUNT+=1
    )
)

REM ============================================================
REM KY TAT CA FILE LUAC
REM ============================================================
echo.
echo ============================================================
echo BAT DAU KY FILE .LUAC
echo ============================================================
echo.

for /r "%PLUGIN%" %%F in (*.luac) do (

    set "SRC=%%~fF"

    REM Bo qua Sig
    echo(!SRC!| findstr /i /b /c:"%SIGROOT%\" >nul

    if errorlevel 1 (

        REM Lay duong dan tuong doi
        set "REL=%%~fF"
        set "REL=!REL:%PLUGIN%\=!"

        REM Tao duong dan SIG
        set "SIG=%SIGROOT%\!REL!.sig"

        REM Tao thu muc cha cua SIG
        for %%D in ("!SIG!") do (
            if not exist "%%~dpD" mkdir "%%~dpD"
        )

        REM Chuyen ca SRC va SIG sang duong dan 8.3
        set "SRC_S=%%~sF"

        for %%S in ("!SIG!") do (
            set "SIG_S=%%~sS"
        )

        echo ------------------------------------------------------------
        echo KY:
        echo    !SRC!
        echo.
        echo    ^> !SIG!
        echo.

        "%OPENSSL%" dgst -sha256 -sign "%PRIVATE_KEY%" -out "!SIG_S!" "!SRC_S!"

        if errorlevel 1 (
            echo.
            echo LOI KHI KY FILE LUAC:
            echo    !SRC!
            echo.
            echo Duong dan nguon:
            echo    !SRC_S!
            echo.
            echo Duong dan chu ky:
            echo    !SIG_S!
            echo.
            pause
            exit /b 1
        )

        echo OK
        echo.

        set /a COUNT+=1
    )
)

REM ============================================================
REM HOAN TAT
REM ============================================================
echo.
echo ============================================================
echo HOAN TAT KY CHU KY
echo ============================================================
echo.
echo Plugin:
echo    %PLUGIN%
echo.
echo Da ky: !COUNT! file
echo.
echo Chu ky nam tai:
echo    %SIGROOT%
echo.
echo ============================================================
echo.

pause
